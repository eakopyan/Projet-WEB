from django.contrib import admin
from blog.models import User, Event, Aliment, Ramener, Objectif


class MembershipInLine(admin.TabularInline):
	model = Event.participants.through

class ConsoInLine(admin.TabularInline):
	model = Event.conso.through

class UserAdmin(admin.ModelAdmin):
	inlines = [
		MembershipInLine,
	]

class EventAdmin(admin.ModelAdmin):
	inlines = [
		MembershipInLine,
		ConsoInLine,
	]
	exclude = ('participants','conso') #à mettre obligatoirement

class AlimentAdmin(admin.ModelAdmin):
	inlines = [
		ConsoInLine,
	]

# Register your models here.
admin.site.register(User, UserAdmin)
admin.site.register(Event)
admin.site.register(Aliment, AlimentAdmin)
admin.site.register(Ramener)
admin.site.register(Objectif)





