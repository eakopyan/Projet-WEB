from django.db import models
from django.utils import timezone

# Create your models here.

class User(models.Model):
	username = models.CharField(max_length=50)
	password = models.CharField(max_length = 20)

	 #pour l'url plus belle, facultatif
	#slug = models.SlugField(max_length = 100)
	class Meta:
		verbose_name="utilisateur"
		ordering=['username'] #trier par nom d'user

	def __str__(self):
		""""
		Aucune idee de ce que c'est cette merde, mais ça beug sinon"""


		return self.username

class Aliment(models.Model):
	nom = models.CharField(max_length=100)
	unité = models.CharField(max_length=42)

	class Meta:
		verbose_name = "à consommer"

	def __str__(self):

		return self.nom
class Event(models.Model):
	name = models.CharField(max_length=100)
	descritption = models.TextField(null=True) #pas de limite
	date = models.DateTimeField(default=timezone.now, verbose_name= "Date de l'evenement")
	

	participants = models.ManyToManyField(User)
	conso = models.ManyToManyField(Aliment)
	
	class Meta:
		verbose_name="evenement"
		ordering = ['date'] #trier par date

	def __str__(self):
		""""
		Aucune idée de ce que c'est cette merde, mais ça beug sinon"""
		return self.name




class Objectif(models.Model):
    quantite_voulue = models.IntegerField()
    quantite_actuelle = models.IntegerField()
    class Meta:
        verbose_name = "Objectif"
    def __str__(self):

        return self.quantite_voulue

class Ramener(models.Model):
	quantite = models.IntegerField()

	class Meta:
		verbose_name = "Link"

	def __str__(self):
		return self.quantite
